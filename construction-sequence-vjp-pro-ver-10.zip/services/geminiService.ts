import { GoogleGenAI, VideoGenerationReferenceType } from "@google/genai";
import { Keyframe } from "../types";

// Always create a new instance right before the call to pick up the latest API key from the environment
export const generateConstructionVideo = async (
  keyframes: Keyframe[],
  onStatusUpdate: (status: string) => void
): Promise<string | null> => {
  // Use a new instance to ensure it uses the most up-to-date API key from the dialog
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Use the first few keyframes as primary references
  // Veo 3.1 supports up to 3 reference images
  const refImages = keyframes.slice(0, 3);
  
  const referenceImagesPayload = refImages.map(kf => ({
    image: {
      imageBytes: kf.image.split(',')[1], // Remove prefix
      mimeType: 'image/png',
    },
    referenceType: VideoGenerationReferenceType.ASSET,
  }));

  const prompt = `Create a professional construction time-lapse video sequence based on these reference images. 
    The video should show the building progressing from an early stage to a more complete state. 
    The style should be clean, high-end architectural visualization.`;

  onStatusUpdate("Initializing video generation operation...");

  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        referenceImages: referenceImagesPayload,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    onStatusUpdate("Processing frames (this may take a few minutes)...");

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    if (operation.error) {
      throw new Error(String(operation.error.message));
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) throw new Error("Video URI not found in response");

    onStatusUpdate("Finalizing video file...");
    // Must append API key when fetching from the download link as per guidelines
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  } catch (error) {
    console.error("Video Generation Error:", error);
    throw error;
  }
};