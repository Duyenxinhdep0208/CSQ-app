
import React, { memo, useRef } from 'react';
import { Keyframe } from '../types';

interface KeyframeListProps {
  keyframes: Keyframe[];
  onAdd: () => void;
  onRemove: (id: string) => void;
  onSelect: (kf: Keyframe) => void;
  onUpdate: (id: string, updates: Partial<Keyframe>) => void;
  onEdit: (type: any, id: string, label: string, value: string) => void;
  selectedId: string | null;
}

const KeyframeList: React.FC<KeyframeListProps> = ({ keyframes, onAdd, onRemove, onSelect, onUpdate, onEdit, selectedId }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeKfIdRef = useRef<string | null>(null);

  const formatDate = (d: Date) => `${d.getMonth() + 1}/${d.getFullYear()}`;

  const sortedKeyframes = [...keyframes].sort((a, b) => a.startDate.getTime() - b.startDate.getTime());

  const handleAudioUploadClick = (id: string) => {
    activeKfIdRef.current = id;
    if (fileInputRef.current) fileInputRef.current.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && activeKfIdRef.current) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = (evt) => {
            if (evt.target?.result) {
                onUpdate(activeKfIdRef.current!, { 
                    audioData: evt.target.result as string,
                    audioName: file.name
                });
            }
        };
        reader.readAsDataURL(file);
    }
    // Reset
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white">
      <div className="p-4 flex justify-between items-center border-b border-slate-100">
        <h2 className="text-[10px] font-black tracking-widest text-slate-400 uppercase">PROJECT STAGES</h2>
        <button 
          onClick={onAdd}
          className="bg-blue-600 text-white text-[8px] px-3 py-1.5 rounded font-black uppercase shadow-sm hover:bg-blue-700 transition-all active:scale-95"
        >
          INSERT DATA
        </button>
      </div>
      
      {/* Hidden file input for audio */}
      <input 
        type="file" 
        accept="audio/*" 
        ref={fileInputRef} 
        className="hidden" 
        onChange={handleFileChange}
      />
      
      <div className="flex-1 overflow-y-auto px-4 pb-4 space-y-4 relative pt-4">
        <div className="absolute left-[34px] top-0 bottom-0 w-0.5 bg-blue-500/10" />
        {sortedKeyframes.map((kf, index) => (
          <div 
            key={kf.id}
            onClick={() => onSelect(kf)}
            className={`relative flex items-center gap-4 cursor-pointer group transition-all ${selectedId === kf.id ? 'opacity-100' : 'opacity-70 hover:opacity-100'}`}
          >
            <div className={`w-3 h-3 rounded-full border-2 bg-white transition-all z-10 ${selectedId === kf.id ? 'border-blue-500 scale-125 shadow-[0_0_8px_rgba(59,130,246,0.5)]' : 'border-slate-300'}`} />
            
            <div 
              className={`flex-1 bg-white border rounded-xl p-3 flex flex-col gap-3 shadow-sm transition-all hover:shadow-md ${selectedId === kf.id ? 'border-blue-500 ring-1 ring-blue-500/20' : 'border-slate-100'}`}
            >
               <div className="flex gap-3">
                  <img 
                    src={kf.image} 
                    className="w-16 h-14 object-cover rounded-lg bg-slate-100 flex-shrink-0" 
                    loading="lazy"
                    decoding="async"
                  />
                  <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-[7px] font-black text-blue-500 uppercase tracking-widest">STAGE_{index.toString().padStart(2, '0')}</span>
                        <button 
                          onClick={(e) => { e.stopPropagation(); onRemove(kf.id); }} 
                          className="text-slate-300 hover:text-red-500 transition-colors p-1"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12"/></svg>
                        </button>
                      </div>
                      
                      <div 
                        className="text-[11px] font-black text-slate-800 uppercase truncate hover:text-blue-600 transition-colors flex items-center gap-1 group/title"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEdit('keyframe-subtitle', kf.id, 'EDIT STAGE TITLE', kf.subtitle);
                        }}
                      >
                        {kf.subtitle || 'UNNAMED STAGE'}
                        <svg className="w-2.5 h-2.5 opacity-0 group-hover/title:opacity-100 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
                      </div>

                      <div className="flex gap-2 mt-1">
                        <button 
                          className="bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded text-[7px] font-bold text-slate-500 uppercase hover:bg-blue-50 hover:text-blue-600 hover:border-blue-100 transition-all"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEdit('keyframe-start', kf.id, 'EDIT START (MM/YYYY)', formatDate(kf.startDate));
                          }}
                        >
                          BEG: {kf.startDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }).toUpperCase()}
                        </button>
                        <button 
                          className="bg-slate-50 border border-slate-100 px-1.5 py-0.5 rounded text-[7px] font-bold text-slate-500 uppercase hover:bg-blue-50 hover:text-blue-600 hover:border-blue-100 transition-all"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEdit('keyframe-end', kf.id, 'EDIT END (MM/YYYY)', formatDate(kf.endDate));
                          }}
                        >
                          END: {kf.endDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }).toUpperCase()}
                        </button>
                      </div>
                  </div>
               </div>

               <div className="pt-2 border-t border-slate-50">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Audio Source</span>
                    <div className="flex gap-1">
                        {/* Audio Upload Button */}
                        <button 
                            onClick={(e) => {
                                e.stopPropagation();
                                handleAudioUploadClick(kf.id);
                            }}
                            title={kf.audioData ? "Change Audio File" : "Upload Custom Audio"}
                            className={`text-[7px] font-black px-1.5 py-0.5 rounded border transition-all uppercase flex items-center gap-1 ${kf.audioData ? 'bg-purple-100 border-purple-300 text-purple-700' : 'bg-slate-50 border-slate-200 text-slate-400 hover:bg-purple-50 hover:text-purple-600'}`}
                        >
                            {kf.audioData ? (
                                <>
                                    <span className="w-1.5 h-1.5 bg-purple-500 rounded-full animate-pulse"></span>
                                    FILE LOADED
                                </>
                            ) : 'UP AUDIO'}
                        </button>
                        
                        {/* Remove Audio Button (Only if exists) */}
                        {kf.audioData && (
                            <button 
                                onClick={(e) => { e.stopPropagation(); onUpdate(kf.id, { audioData: undefined }); }} 
                                className="text-[7px] font-black px-1.5 py-0.5 rounded border border-red-200 bg-red-50 text-red-500 hover:bg-red-100 hover:text-red-700 transition-colors uppercase"
                                title="Remove Custom Audio"
                            >
                                REMOVE
                            </button>
                        )}

                        {/* Inherit Toggle */}
                        {index > 0 && (
                        <button 
                            onClick={(e) => {
                            e.stopPropagation();
                            onUpdate(kf.id, { usePreviousNarration: !kf.usePreviousNarration });
                            }}
                            className={`text-[7px] font-black px-1.5 py-0.5 rounded border transition-all uppercase ${kf.usePreviousNarration ? 'bg-blue-500 border-blue-400 text-white' : 'bg-slate-50 border-slate-200 text-slate-400 hover:border-blue-300'}`}
                        >
                            {kf.usePreviousNarration ? 'Nối Tiếp' : 'Ngắt Dòng'}
                        </button>
                        )}
                    </div>
                  </div>

                  {/* Text Input - ALWAYS VISIBLE now */}
                  {!kf.usePreviousNarration ? (
                    <div 
                      className={`relative text-[9px] font-medium p-2 rounded-lg border transition-colors cursor-text group/text ${kf.audioData ? 'bg-purple-50/30 border-purple-200 text-slate-700' : 'bg-slate-50/50 text-slate-600 border-slate-100 hover:border-blue-200'}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onEdit('keyframe-narration', kf.id, 'EDIT NARRATION TEXT (SUBTITLE)', kf.narration || kf.description);
                      }}
                    >
                      {/* Visual indicator that this text is backed by custom audio */}
                      {kf.audioData && (
                          <div className="absolute right-1 top-1 opacity-50">
                              <span title="Audio played from file, Text shown on screen" className="text-[10px]">🎵</span>
                          </div>
                      )}
                      
                      <div className="pr-4 min-h-[1.5em]">
                        {kf.narration || kf.description || (
                            <span className="italic text-slate-400">Click to add subtitles/narration text...</span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-[9px] font-bold italic text-blue-400 px-2 py-2">
                      (Đang sử dụng nội dung từ stage trước...)
                    </div>
                  )}
               </div>
            </div>
          </div>
        ))}
        {keyframes.length === 0 && (
          <div className="text-center py-20 flex flex-col items-center gap-4">
            <svg className="w-12 h-12 text-slate-100" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
            <span className="text-[9px] text-slate-300 uppercase font-black tracking-widest italic px-8">Upload site photos to build your sequence</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default memo(KeyframeList);
