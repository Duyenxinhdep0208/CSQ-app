
import React, { useMemo, memo } from 'react';
import ProgressCircle from './ProgressCircle';

interface TimelineProps {
  startDate: Date;
  endDate: Date;
  currentDate: Date;
  onDateChange: (date: Date) => void;
  totalProgress: number;
}

const Timeline: React.FC<TimelineProps> = ({ startDate, endDate, currentDate, onDateChange, totalProgress }) => {
  const months = useMemo(() => {
    const m = [];
    let iter = new Date(startDate);
    if (isNaN(iter.getTime()) || isNaN(endDate.getTime()) || startDate > endDate) {
        return [];
    }
    const end = new Date(endDate);
    
    while (iter <= end) {
      m.push(new Date(iter));
      iter.setMonth(iter.getMonth() + 1);
    }
    return m;
  }, [startDate.getTime(), endDate.getTime()]);

  const years = useMemo(() => {
    return Array.from(new Set(months.map(m => m.getFullYear())));
  }, [months]);

  return (
    <div className="w-full bg-white border-b border-slate-200 flex select-none h-[72px] flex-shrink-0">
      <div className="w-48 border-r border-slate-200 flex items-center px-4 gap-3 bg-slate-50/30">
        <ProgressCircle progress={totalProgress} size="xs" color="#2563eb" />
        <div className="flex flex-col">
          <span className="text-[7px] font-black text-slate-400 tracking-widest leading-none">PROJECT</span>
          <span className="text-[9px] font-black text-blue-900 leading-tight">TOTAL PROGRESS</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        <div className="flex border-b border-slate-100 h-6 items-center">
          {years.map((year) => {
            const yearMonths = months.filter(m => m.getFullYear() === year);
            return (
              <div 
                key={year} 
                style={{ flex: yearMonths.length }} 
                className="text-center text-[10px] font-black text-blue-600 tracking-widest border-l border-slate-100 first:border-l-0"
              >
                {year}
              </div>
            );
          })}
        </div>
        
        <div className="flex bg-slate-50/50 p-1 gap-1 overflow-x-auto scrollbar-hide h-12 items-center">
          {months.map((m, idx) => {
            const isCurrent = m.getMonth() === currentDate.getMonth() && m.getFullYear() === currentDate.getFullYear();
            const year = m.getFullYear();
            
            let bgColor = year % 2 === 0 ? 'bg-blue-100/50 text-blue-800' : 'bg-indigo-100/50 text-indigo-800';
            if (isCurrent) bgColor = 'bg-slate-900 text-white shadow-md z-10 ring-1 ring-slate-900';

            return (
              <div 
                key={idx}
                onClick={() => onDateChange(m)}
                className={`flex-1 min-w-[36px] h-8 flex items-center justify-center rounded-sm text-[8px] font-black cursor-pointer transition-colors hover:opacity-80 ${bgColor}`}
              >
                {/* Use 'en-US' for JAN, FEB... style */}
                {m.toLocaleString('en-US', { month: 'short' }).toUpperCase()}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default memo(Timeline);
