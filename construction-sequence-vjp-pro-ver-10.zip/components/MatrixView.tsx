import React, { useMemo } from 'react';
import { Keyframe, Task, EditState, OverlayConfig } from '../types';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';

interface MatrixViewProps {
  keyframes: Keyframe[];
  tasks: Task[];
  projectStartDate: Date;
  projectEndDate: Date;
  onEdit: (state: EditState) => void;
  onUpdateKeyframe: (id: string, updates: Partial<Keyframe>) => void;
  overlayConfig: OverlayConfig;
}

const MatrixView: React.FC<MatrixViewProps> = ({
  keyframes,
  tasks,
  projectStartDate,
  projectEndDate,
  onEdit,
  onUpdateKeyframe,
  overlayConfig
}) => {

  const projectMonths = useMemo(() => {
    const months: Date[] = [];
    const start = new Date(projectStartDate);
    const end = new Date(projectEndDate);
    // Normalize to start of month
    start.setDate(1);
    end.setDate(1);
    
    const current = new Date(start);
    while (current <= end) {
      months.push(new Date(current));
      current.setMonth(current.getMonth() + 1);
    }
    return months;
  }, [projectStartDate, projectEndDate]);

  const sortedData = useMemo(() => {
    // Only return keyframes, sorted by date
    return [...keyframes].sort((a, b) => a.startDate.getTime() - b.startDate.getTime());
  }, [keyframes]);

  const formatDate = (d: Date) => `${d.getMonth() + 1}/${d.getFullYear()}`;
  const getMonthKey = (d: Date) => `${d.getFullYear()}-${d.getMonth() + 1}`;

  // Calculate row spans for merged columns (Narration, Start, End)
  const rowSpans = useMemo(() => {
    const spans = new Map<string, { span: number, isLeader: boolean, groupEnd: Date }>();
    let currentLeaderId = '';
    let currentSpan = 0;
    let groupStartIndex = 0;

    for (let i = 0; i < sortedData.length; i++) {
        const kf = sortedData[i];
        
        // A new group starts if it's the first item OR usePreviousNarration is false
        // However, if usePreviousNarration is true, it belongs to the previous group
        if (i === 0 || !kf.usePreviousNarration) {
            // Finish previous group
            if (currentLeaderId) {
                // The groupEnd is the endDate of the LAST item in the group (which is at i-1)
                const groupEndDate = sortedData[i-1].endDate;
                spans.set(currentLeaderId, { span: currentSpan, isLeader: true, groupEnd: groupEndDate });
            }
            
            // Start new group
            currentLeaderId = kf.id;
            currentSpan = 1;
            groupStartIndex = i;
            spans.set(kf.id, { span: 1, isLeader: true, groupEnd: kf.endDate }); // Temporary
        } else {
            // Continue group
            currentSpan++;
            spans.set(kf.id, { span: 0, isLeader: false, groupEnd: kf.endDate }); // Not a leader
        }
    }
    // Finish last group
    if (currentLeaderId && sortedData.length > 0) {
        const groupEndDate = sortedData[sortedData.length - 1].endDate;
        spans.set(currentLeaderId, { span: currentSpan, isLeader: true, groupEnd: groupEndDate });
    }
    return spans;
  }, [sortedData]);

  // Calculate row spans for Progress column (grouped by Month)
  const progressRowSpans = useMemo(() => {
    const spans = new Map<string, { span: number, isLeader: boolean }>();
    let currentLeaderId = '';
    let currentSpan = 0;
    let currentMonthKey = '';

    for (let i = 0; i < sortedData.length; i++) {
        const kf = sortedData[i];
        const monthKey = getMonthKey(kf.startDate);
        
        if (i === 0 || monthKey !== currentMonthKey) {
            // Finish previous group
            if (currentLeaderId) {
                spans.set(currentLeaderId, { span: currentSpan, isLeader: true });
            }
            
            // Start new group
            currentLeaderId = kf.id;
            currentSpan = 1;
            currentMonthKey = monthKey;
            spans.set(kf.id, { span: 1, isLeader: true });
        } else {
            // Continue group
            currentSpan++;
            spans.set(kf.id, { span: 0, isLeader: false });
        }
    }
    // Finish last group
    if (currentLeaderId) {
        spans.set(currentLeaderId, { span: currentSpan, isLeader: true });
    }
    return spans;
  }, [sortedData]);

  const getTasksForStage = (stageStart: Date, stageEnd: Date) => {
    return tasks.filter(t => {
      // Check for overlap: Task Start <= Stage End AND Task End >= Stage Start
      return t.startDate <= stageEnd && t.endDate >= stageStart;
    });
  };

  const handleAudioUpload = (e: React.ChangeEvent<HTMLInputElement>, id: string) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateKeyframe(id, { 
            audioData: reader.result as string,
            audioName: file.name
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const exportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Project Matrix');

    // Define columns
    const columns = [
      { header: 'Stage Name', key: 'stageName', width: 25 },
      { header: 'Tasks', key: 'tasks', width: 40 },
      { header: 'Start', key: 'start', width: 12 },
      { header: 'End', key: 'end', width: 12 },
      { header: 'Progress', key: 'progress', width: 10 },
      { header: 'Narration/Audio', key: 'narration', width: 35 },
      ...projectMonths.map(m => ({ header: formatDate(m), key: m.toISOString(), width: 8 }))
    ];
    
    worksheet.columns = columns;

    // Style Header Row
    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true, color: { argb: 'FF64748B' } }; // slate-500
    headerRow.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFF1F5F9' } // slate-100
    };
    headerRow.eachCell((cell) => {
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        right: { style: 'thin', color: { argb: 'FFE2E8F0' } }
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    // Add Data
    sortedData.forEach((k, index) => {
      const rowIndex = index + 2;
      const row = worksheet.getRow(rowIndex);
      
      const stageTasks = getTasksForStage(k.startDate, k.endDate);
      const taskNames = stageTasks.map(t => t.name).join(', ');
      
      // Basic data
      row.getCell('stageName').value = k.subtitle;
      row.getCell('tasks').value = taskNames;
      
      // Styling for basic cells
      row.getCell('stageName').font = { bold: true, color: { argb: 'FF2563EB' } }; // blue-600
      row.getCell('stageName').alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
      row.getCell('tasks').alignment = { vertical: 'top', horizontal: 'left', wrapText: true };
      
      // Merged Columns Logic
      const spanInfo = rowSpans.get(k.id);
      const isLeader = spanInfo?.isLeader;
      const spanCount = spanInfo?.span || 0;
      // groupEndDate is no longer needed for individual rows, but kept if needed for narration logic
      
      // Always set Start and End dates (No merging)
      row.getCell('start').value = formatDate(k.startDate);
      row.getCell('end').value = formatDate(k.endDate);

      if (isLeader) {
        row.getCell('narration').value = k.narration || (k.audioName ? `Audio: ${k.audioName}` : '');
        
        if (spanCount > 1) {
            worksheet.mergeCells(rowIndex, 6, rowIndex + spanCount - 1, 6); // Narration
        }
      }
      
      // Progress Merging Logic
      const progressSpanInfo = progressRowSpans.get(k.id);
      const isProgressLeader = progressSpanInfo?.isLeader;
      const progressSpanCount = progressSpanInfo?.span || 0;

      if (isProgressLeader) {
          row.getCell('progress').value = `${k.progress}%`;
          if (progressSpanCount > 1) {
              worksheet.mergeCells(rowIndex, 5, rowIndex + progressSpanCount - 1, 5); // Progress
          }
      }

      // Month Columns (Active State)
      projectMonths.forEach((m, mIdx) => {
        const colIndex = 7 + mIdx; // 1-based index: 6 fixed cols + current month index + 1
        const isActive = getMonthKey(m) === getMonthKey(k.startDate);
        
        const cell = row.getCell(colIndex);
        if (isActive) {
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: 'FFDBEAFE' } // blue-100
            };
            // Add a "dot" symbol or similar to represent the active state visually if needed, 
            // but background color is usually enough. Let's add a small circle char.
            cell.value = '●';
            cell.font = { color: { argb: 'FF3B82F6' }, size: 14 }; // blue-500
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
        }
        cell.border = {
            left: { style: 'thin', color: { argb: 'FFF1F5F9' } } // slate-100
        };
      });

      // Common styling for merged/data cells
      ['start', 'end', 'progress', 'narration'].forEach(key => {
          const cell = row.getCell(key);
          cell.alignment = { vertical: 'top', horizontal: key === 'narration' ? 'left' : 'center', wrapText: true };
          if (key === 'progress') {
              cell.font = { bold: true, color: { argb: 'FF2563EB' } };
          }
      });
      
      // Row borders
      row.eachCell((cell) => {
          if (!cell.border) {
             cell.border = {};
          }
          cell.border.bottom = { style: 'thin', color: { argb: 'FFE2E8F0' } };
      });
    });

    // Design Settings Sheet
    const settingsSheet = workbook.addWorksheet('Design Settings');
    settingsSheet.columns = [
        { header: 'Setting Name', key: 'name', width: 40 },
        { header: 'Value', key: 'value', width: 40 }
    ];
    
    // Define Sections
    const DESIGN_SECTIONS = [
      {
        title: '1. Global Settings',
        keys: ['fontFamily', 'fontWeight', 'fontSizeBase', 'overlayOpacity', 'accentColor']
      },
      {
        title: '2. Timeline',
        keys: ['timelineHeight', 'timelineBgColor', 'timelineYearColor', 'timelineYearFontSize', 'timelineYearFontWeight']
      },
      {
        title: '3. Timeline Progress Bar',
        keys: ['timelineProgressBarShow', 'timelineProgressBarHeight', 'timelineProgressBarColor', 'timelineProgressBarOpacity']
      },
      {
        title: '4. Timeline Labels',
        keys: ['timelineLabelShow', 'timelineLabelText', 'timelineLabelColor', 'timelineLabelFontSize', 'timelineLabelFontWeight', 'timelineLabelFontFamily', 'timelineLabelX', 'timelineLabelY']
      },
      {
        title: '5. Timeline Months',
        keys: ['timelineMonthFontSize', 'timelineMonthFontWeight', 'timelineMonthOpacity', 'monthActiveBg', 'monthInactiveBg', 'monthPastBg', 'monthNextBg', 'monthTextColor', 'monthActiveScale', 'monthInactiveScale', 'monthActiveFontSize', 'monthBorderRadius']
      },
      {
        title: '6. Project Progress Circle',
        keys: ['circleColor', 'circleOpacity', 'circleX', 'circleY', 'circleScale', 'progressStrokeWidth']
      },
      {
        title: '7. Circle Background',
        keys: ['circleRectShow', 'circleRectColor', 'circleRectOpacity', 'circleRectWidth', 'circleRectHeight', 'circleRectX', 'circleRectY', 'circleRectBorderRadius']
      },
      {
        title: '8. Circle Labels',
        keys: ['circleShowLabel', 'circleLabelPosition', 'circleLabelDistance', 'circleLabelFontSize', 'circleLabelColor', 'circleLabelFontFamily', 'circleLabelLine1', 'circleLabelLine2']
      },
      {
        title: '9. Task Graphics',
        keys: ['taskX', 'taskY', 'taskCircleScale', 'taskPrimaryColor', 'taskCircleBgColor', 'taskOpacity', 'taskLabelBgColor', 'taskLabelBgOpacity', 'taskLabelPosition', 'taskSpacingY', 'taskFontSize', 'taskPercentFontSize', 'taskFontFamily', 'taskFontWeight', 'taskLabelBorderShow']
      },
      {
        title: '10. Narration Bar',
        keys: ['narrationBarShow', 'narrationFontFamily', 'narrationFontSize']
      }
    ];

    // Remove default header row created by columns definition to custom build it
    settingsSheet.spliceRows(1, 1);

    let currentRow = 1;

    DESIGN_SECTIONS.forEach(section => {
        // Section Header
        const headerRow = settingsSheet.getRow(currentRow);
        headerRow.values = [section.title.toUpperCase(), ''];
        settingsSheet.mergeCells(currentRow, 1, currentRow, 2);
        
        headerRow.font = { bold: true, color: { argb: 'FF1E293B' }, size: 12 }; // slate-800
        headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2E8F0' } }; // slate-200
        headerRow.getCell(1).alignment = { vertical: 'middle', horizontal: 'left' };
        headerRow.height = 25;
        
        // Add border to header
        headerRow.getCell(1).border = {
            top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
            right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
        };

        currentRow++;

        // Section Items
        section.keys.forEach(key => {
            if (key in overlayConfig) {
                const row = settingsSheet.getRow(currentRow);
                // Format key name: camelCase -> Title Case (e.g., timelineHeight -> Timeline Height)
                const formattedKey = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                
                row.getCell(1).value = formattedKey;
                row.getCell(2).value = String(overlayConfig[key as keyof OverlayConfig]);
                
                // Styling
                row.getCell(1).font = { color: { argb: 'FF64748B' }, bold: true }; // slate-500
                row.getCell(2).font = { color: { argb: 'FF334155' } }; // slate-700
                row.getCell(2).alignment = { horizontal: 'left' };
                
                // Borders
                row.getCell(1).border = { bottom: { style: 'dotted', color: { argb: 'FFF1F5F9' } }, right: { style: 'thin', color: { argb: 'FFF1F5F9' } } };
                row.getCell(2).border = { bottom: { style: 'dotted', color: { argb: 'FFF1F5F9' } } };

                currentRow++;
            }
        });
        
        // Add a spacer row
        currentRow++;
    });

    // Generate and Save
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, 'Construction_Sequence_Matrix.xlsx');
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      <div className="flex justify-between items-center p-4 bg-white border-b border-slate-200">
        <h2 className="text-lg font-bold text-slate-800">Project Matrix View</h2>
        <button 
          onClick={exportToExcel}
          className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm font-bold flex items-center gap-2 transition-colors"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
          Export to Excel
        </button>
      </div>
      
      <div className="flex-1 overflow-auto p-4">
        <div className="inline-block min-w-full align-middle">
          <div className="border border-slate-200 rounded-lg overflow-hidden shadow-sm">
            <table className="min-w-full divide-y divide-slate-200 border-collapse">
              <thead className="bg-slate-100 sticky top-0 z-20">
                <tr>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider sticky left-0 bg-slate-100 z-30 border-r border-slate-200 shadow-[4px_0_8px_-4px_rgba(0,0,0,0.1)]">Stage Name</th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[200px]">Tasks</th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Start</th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">End</th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">Progress</th>
                  <th scope="col" className="px-3 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[200px]">Narration/Audio</th>
                  {projectMonths.map(m => (
                    <th key={m.toISOString()} scope="col" className="px-2 py-3 text-center text-[10px] font-bold text-slate-500 uppercase tracking-wider min-w-[60px] border-l border-slate-200">
                      {formatDate(m)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {sortedData.map((k, idx) => {
                    const stageTasks = getTasksForStage(k.startDate, k.endDate);
                    const spanInfo = rowSpans.get(k.id);
                    const isLeader = spanInfo?.isLeader;
                    const spanCount = spanInfo?.span || 0;
                    const groupEndDate = spanInfo?.groupEnd || k.endDate;
                    const progressSpanInfo = progressRowSpans.get(k.id);
                    const isProgressLeader = progressSpanInfo?.isLeader;
                    const progressSpanCount = progressSpanInfo?.span || 0;
                    
                    return (
                      <tr key={k.id} className="hover:bg-blue-50 transition-colors group">
                        <td 
                          className="px-3 py-2 whitespace-nowrap sticky left-0 bg-white group-hover:bg-blue-50 z-10 border-r border-slate-200 text-sm font-bold text-blue-600 cursor-pointer hover:underline"
                          onClick={() => onEdit({ type: 'keyframe-subtitle', id: k.id, label: 'EDIT SUBTITLE', value: k.subtitle })}
                        >
                          {k.subtitle}
                        </td>
                        <td className="px-3 py-2 text-xs text-slate-600 min-w-[200px]">
                            <div className="flex flex-wrap gap-1">
                                {stageTasks.length > 0 ? stageTasks.map(t => (
                                    <span 
                                        key={t.id} 
                                        className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-orange-100 text-orange-800 cursor-pointer hover:bg-orange-200 border border-orange-200"
                                        onClick={() => onEdit({ type: 'task-name', id: t.id, label: 'EDIT TASK NAME', value: t.name })}
                                        title={`Start: ${formatDate(t.startDate)} - End: ${formatDate(t.endDate)}`}
                                    >
                                        {t.name}
                                    </span>
                                )) : <span className="text-slate-400 italic text-[10px]">No tasks</span>}
                            </div>
                        </td>
                        
                        {/* Start Date (No Merging) */}
                        <td 
                          className="px-3 py-2 whitespace-nowrap text-xs text-slate-500 cursor-pointer hover:text-blue-600 align-top bg-white border-b border-slate-200"
                          onClick={() => onEdit({ type: 'keyframe-start', id: k.id, label: 'EDIT START DATE', value: formatDate(k.startDate) })}
                        >
                          {formatDate(k.startDate)}
                        </td>

                        {/* End Date (No Merging) */}
                        <td 
                          className="px-3 py-2 whitespace-nowrap text-xs text-slate-500 cursor-pointer hover:text-blue-600 align-top bg-white border-b border-slate-200"
                          // Note: Editing this updates the individual item's end date
                        >
                          {formatDate(k.endDate)}
                        </td>

                        {/* Merged Progress */}
                        {isProgressLeader ? (
                            <td 
                              className="px-3 py-2 whitespace-nowrap text-xs font-bold text-blue-600 cursor-pointer hover:text-blue-800 align-top bg-white border-b border-slate-200"
                              rowSpan={progressSpanCount}
                              onClick={() => onEdit({ type: 'keyframe-progress', id: k.id, label: 'EDIT PROGRESS %', value: k.progress.toString() })}
                            >
                              {k.progress}%
                              {progressSpanCount > 1 && <span className="block text-[8px] font-normal text-slate-400 italic">For {formatDate(k.startDate)}</span>}
                            </td>
                        ) : null}

                        {/* Merged Narration/Audio */}
                        {isLeader ? (
                            <td 
                                className="px-3 py-2 text-xs text-slate-500 min-w-[200px] align-top bg-white border-b border-slate-200"
                                rowSpan={spanCount}
                            >
                              <div className="flex flex-col gap-1 sticky top-14">
                                <div 
                                  className="cursor-pointer hover:text-blue-600 italic"
                                  onClick={() => onEdit({ type: 'keyframe-narration', id: k.id, label: 'EDIT NARRATION', value: k.narration || '' })}
                                >
                                  {k.narration || 'No narration'}
                                </div>
                                <div className="flex items-center gap-2 mt-1">
                                    <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-600 text-[9px] font-bold px-2 py-1 rounded flex items-center gap-1 transition-colors">
                                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                                        {k.audioData ? 'Change Audio' : 'Upload Audio'}
                                        <input type="file" accept="audio/*" className="hidden" onChange={(e) => handleAudioUpload(e, k.id)} />
                                    </label>
                                    {k.audioData && <span className="text-[9px] text-green-600 font-bold truncate max-w-[120px]" title={k.audioName}>✓ {k.audioName || 'Audio Set'}</span>}
                                </div>
                                {spanCount > 1 && (
                                    <span className="text-[9px] text-slate-400 italic mt-1 border-t border-slate-100 pt-1">
                                        Applied to {spanCount} stages
                                    </span>
                                )}
                              </div>
                            </td>
                        ) : null}

                        {projectMonths.map(m => {
                           const isActive = getMonthKey(m) === getMonthKey(k.startDate);
                           return (
                             <td key={m.toISOString()} className={`px-2 py-2 border-l border-slate-100 text-center ${isActive ? 'bg-blue-100' : ''}`}>
                               {isActive && <div className="w-3 h-3 bg-blue-500 rounded-full mx-auto"></div>}
                             </td>
                           );
                        })}
                      </tr>
                    );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MatrixView;
