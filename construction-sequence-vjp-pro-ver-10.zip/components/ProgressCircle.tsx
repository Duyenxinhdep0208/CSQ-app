
import React from 'react';

interface ProgressCircleProps {
  progress: number;
  label?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  color?: string;
  dark?: boolean;
}

const ProgressCircle: React.FC<ProgressCircleProps> = ({ progress, label, size = 'md', color = '#ef4444', dark = false }) => {
  const dimensions = {
    xs: { box: 32, r: 12, strokeBg: 1, strokeFg: 2, font: 'text-[8px]' },
    sm: { box: 48, r: 18, strokeBg: 1, strokeFg: 2, font: 'text-[10px]' },
    md: { box: 70, r: 28, strokeBg: 1.5, strokeFg: 2.5, font: 'text-sm' },
    lg: { box: 96, r: 38, strokeBg: 1.5, strokeFg: 3, font: 'text-xl' },
  };

  const { box, r, strokeBg, strokeFg, font } = dimensions[size];
  const circumference = 2 * Math.PI * r;
  const offset = circumference - (progress / 100) * circumference;
  const center = box / 2;

  return (
    <div className="flex flex-col items-center group pointer-events-auto">
      <div className={`relative bg-white/90 backdrop-blur-md rounded-full shadow-lg border border-white/50 transition-transform hover:scale-110`} style={{ width: box, height: box }}>
        <svg width={box} height={box} className="transform -rotate-90">
          <circle
            cx={center}
            cy={center}
            r={r}
            stroke="#e2e8f0"
            strokeWidth={strokeBg}
            fill="transparent"
          />
          <circle
            cx={center}
            cy={center}
            r={r}
            stroke={color}
            strokeWidth={strokeFg}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-700 ease-in-out"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`${font} font-black tracking-tighter`} style={{ color }}>
            {Math.round(progress)}%
          </span>
        </div>
      </div>
      {label && (
        <div className="mt-1 px-2 py-0.5 bg-blue-900 text-white text-[8px] font-black leading-tight uppercase rounded-sm shadow-md whitespace-nowrap">
          {label}
        </div>
      )}
    </div>
  );
};

export default ProgressCircle;
